<?php 
    include 'include/header.php';
?>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic commodi ab, nemo consequuntur facilis repudiandae officiis accusantium culpa vitae pariatur? Reprehenderit officiis quas animi quasi voluptates in explicabo totam suscipit?
                </p>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Mollitia cumque perspiciatis debitis harum nihil voluptas eligendi libero beatae. Eum ex, libero qui velit autem inventore tempora minus labore omnis dolorum?
                </p>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Architecto quis amet laboriosam magni, ipsa earum sunt, accusamus dolorum atque iusto id aspernatur omnis ipsum dolores? Sequi vero dolores incidunt repudiandae.
                </p>
                <?php 
                    $plik = fopen('dane.txt','r');
                    while (!feof($plik)) {
                        echo "<p>".fgets($plik)."</p>";
                    }
                    fclose($plik);
                ?>
            </div>
        </div>
    </div>

<?php 
    include 'include/footer.php';
?>