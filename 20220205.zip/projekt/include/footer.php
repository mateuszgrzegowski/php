
    <div class="container-fluid">
        <div class="row border bg-light">
            <div class="col-12 text-center">
                <p>CKU Sopot</p>
            </div>
        </div>
    </div>
    
</body>
</html>