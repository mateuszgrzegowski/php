<?php
    // formularz
    $preffix = '/^[a-zA-ZąĄćĆżŻźŹęłŁóÓśS\s]+$/';
    $firstname = '';
    $lastname = '';
    $mail = '';
    $bike = '';
    $comments = '';
    $err = array('firstname'=>'', 'lastname'=>'', 'mail'=>'', 'bike'=>'', 'comments'=>'');

    if (isset($_POST['submit'])) {
        if ($_POST['firstName'] == '') {
            $err['firstname'] = "Wpisz imię";
        } else {
            if(!preg_match($preffix,$_POST['firstName'])) {
                $err['firstname'] = "Wpisz prawidłowo imię";
            } else {
                $firstname = htmlspecialchars($_POST['firstName']);
            }
        }
        if ($_POST['lastName'] == '') {
            $err['lastname'] = "Wpisz nazwisko";
        } else {
            $lastname = $_POST['lastName'];
            if(!preg_match('/^[a-zA-ZąĄćĆżŻźŹęłŁóÓśS\s]+$/',$lastname)) {
                $err['lastname'] = "Wpisz prawidłowo nazwisko.";
                $lastname = '';
            } else {
                $lastname = htmlspecialchars($lastname);
            }
        }
        if ($_POST['mail'] == "") {
            $err['mail'] = "Wpisz adres mailowy.";
        } else {
            $mail = $_POST['mail'];
            if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                $err['mail'] = "Wpisz pradłowy adres mailowy.";
            } else {
                $mail = htmlspecialchars($mail);
            }
        }
        if ($_POST['bike'] == ''){
            $err['bike'] = "Wpisz model roweru";
        } else {
            $bike = htmlspecialchars($_POST['bike']);
        }
        if ($_POST['comments'] == '') {
            $err['comments'] = "Dodaj opis roweru";
        } else {
            $comments = htmlspecialchars($_POST['comments']);
        }
        if (array_filter($err)) {
            echo "Błąd w tablicy";
        } else {

            include('include/config.php');
            $conn = mysqli_connect('localhost',$userdb,$passdb,$db);
            if(!$conn) {
                echo "Błędy połączenia: " . mysqli_connect_error();
            } else {
                // echo "Połaczenie prawidłowe.";
                // zapytnie SQL
                $bike = mysqli_real_escape_string($conn, $bike);
                $comments = mysqli_real_escape_string($conn, $comments);
                $firstname = mysqli_real_escape_string($conn, $firstname);
                $lastname = mysqli_real_escape_string($conn, $lastname);
                $mail = mysqli_real_escape_string($conn, $mail);

                $sql = "INSERT INTO addrowery(Rower, Opis, Imie, Nazwisko, Mail) 
                        VALUE('$bike', '$comments', '$firstname', '$lastname', '$mail')";
                if (mysqli_query($conn, $sql)){
                    mysqli_close($conn);
                    header('Location: index.php');
                } else {
                    echo 'Błąd SQL: ' . mysqli_error($conn);
                }
            }
        }
    }
        

?>

<?php 
    include 'include/header.php';
?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <h1>Formularz dodawanie rowerów</h1>
        </div>
        <div class="col-12">
            <form action="add.php" method="POST">
                <div class="row">
                    <div class="form-group col-6">
                        <label for="firstName">Imię</label>
                        <input type="text" class="form-control" value="<?php echo $firstname; ?>" name="firstName" id="" placeholder="Wpisz imię">
                        <span class="text-danger"><?php echo $err['firstname']; ?></span>
                    </div>
                    <div class="form-group col-6">
                        <label for="lastName">Nazwisko</label>
                        <input type="text" class="form-control" value="<?php echo $lastname; ?>" name="lastName" id="" placeholder="Wpisz nazwisko">
                        <span class="text-danger"><?php echo $err['lastname']; ?></span>
                    </div>
                    <div class="form-group col-12">
                        <label for="mail">Adres mail</label>
                        <input type="text" class="form-control" value="<?php echo $mail; ?>" name="mail" id="" placeholder="Wpisz adres mail">
                        <span class="text-danger"><?php echo $err['mail']; ?></span>
                    </div>
                    <div class="form-group col-12">
                        <label for="bike">Podaj rodzaj roweru</label>
                        <input type="text" class="form-control" value="<?php echo $bike; ?>" name="bike" id="" placeholder="Wpisz rodzaj roweru">
                        <span class="text-danger"><?php echo $err['bike']; ?></span>
                    </div>
                    <div class="form-group col-12">
                        <label for="comments">Opis roweru</label>
                        <textarea name="comments" class="form-control" id="" placeholder="Opis roweru"><?php echo $comments; ?></textarea>
                        <span class="text-danger"><?php echo $err['comments']; ?></span>
                    </div>
                    <div class="form-group col-12">
                        <button type="submit" class="btn btn-primary" name="submit">Wyślij formularz</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php 
    include 'include/footer.php';
?>