<?php
    include('include/config.php');
    $conn = mysqli_connect('localhost',$userdb,$passdb,$db);
    if(!$conn) {
        echo "Błędy połączenia: " . mysqli_connect_error();
    } else {
        // echo "Połaczenie prawidłowe.";
        // zapytnie SQL
        $sql = 'SELECT Rower, Opis, Imie, Nazwisko, Mail FROM addrowery';
        
        $result = mysqli_query($conn, $sql);

        $rowery = mysqli_fetch_all($result,MYSQLI_ASSOC);

        mysqli_free_result($result);

        mysqli_close($conn);

        // print_r($rowery);
    }   
?>

<?php 
    include 'include/header.php';
?>

    <div class="container">
        <div class="row">
            <?php foreach($rowery as $rower) { ?>
                <div class="col-6 card">
                    <div class="card-header">
                        Rower: <?php echo htmlspecialchars($rower['Rower']); ?>
                    </div>
                    <div class="card-body">
                        Opis: <?php echo htmlspecialchars($rower['Opis']); ?>
                    </div>
                    <div class="card-footer text-center">
                        Autor: <?php echo htmlspecialchars($rower['Imie']) . " " . htmlspecialchars($rower['Nazwisko']); ?> 
                    </div>
                    <div class="text-center card-link">
                        <a href="mailto:<?php echo htmlspecialchars($rower['Mail']); ?>" class="btn btn-secondary">Wyślij mail</a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

<?php 
    include 'include/footer.php';
?>