<?php
    $userdb = 'user';
    $passdb = 'user';
    $db  = 'rowery';
?>